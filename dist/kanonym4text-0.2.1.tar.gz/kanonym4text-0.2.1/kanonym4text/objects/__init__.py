from .kanonym import Kanonym

__all__ = ['Kanonym']
