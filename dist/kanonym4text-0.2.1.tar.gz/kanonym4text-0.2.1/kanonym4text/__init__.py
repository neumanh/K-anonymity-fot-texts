#from .k_anonym_text import anonymize, anonymize_llm
from kanonym4text.objects import Kanonym

__all__ = ['Kanonym']


